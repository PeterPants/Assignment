void heapsort(int array[], int size);
void buildheap(int array[], int size);
void percolateDown(int heap[], int size, int id);
void sort(int ar[], int size);
void printArray(int array[], int size);
