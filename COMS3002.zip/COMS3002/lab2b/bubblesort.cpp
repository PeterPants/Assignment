#include <iostream>
#include <string>
#include <sstream>
#include <stdlib.h>
#include "functions.h"
using namespace std;

//void printArray(int array[], int size) {
//	int v=10;
//	for(int i=0; i<size; i++) {
//		if(i==v and v<size){cout<<"\n";v=v+10;}
//		cout << array[i] << " ";
//	}
//	cout << endl;
//}
    void sort(int ar[], int size)
    {
        int temp;
        for(int i = 0; i < size; i++)
            for(int j = 0; j < size - i - 1; j++)
                if(ar[j] > ar[j + 1])
                {
                    temp = ar[j];
                    ar[j] = ar[j + 1];
                    ar[j + 1] = temp;
                }
    }

//    int main()
  //  {
    //    int *array;
      //  int size;
       // cout << "Enter size of array: ";
        //cin >> size;
        //array = new int[size];
      //for(int i=0; i<size; i++){
	//	array[i] = 1+rand()%10000;
	//}
        //cout << "Before sorting: \n "<<endl;
	//printArray(array, size);
        //sort(array, size);
        //cout << "\n After Bubble sorting: \n"<<endl;
	//printArray(array, size);
        //cin.ignore();
        //cin.get();
        //delete array;
        //return 0;
    //}



