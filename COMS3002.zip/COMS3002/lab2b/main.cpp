#include <iostream>
#include <string>
#include <sstream>
#include <stdlib.h>
#include <algorithm>

#include <time.h>
#include "functions.h"
using namespace std;
int compare(const void *elem1,const void *elem2){
return *(int*)elem1-*(int*)elem2;
}
int main() {
  //  clock_t entireProgramTime = clock();
	cout << "Please enter the size of the array" <<endl;
	int size;
	cin >> size;
	int arrayToSort[size];
	for(int i=0; i<size; i++){
		arrayToSort[i] = 1+rand()%65536;
	}


	cout <<"\n";

	clock_t heapSortTime= clock();
	heapsort(arrayToSort, size);
	cout <<"Time taken by heapSort() in seconds: " <<(float)(clock()-heapSortTime)/CLOCKS_PER_SEC <<"\n"<< endl;
	random_shuffle(&arrayToSort[0], &arrayToSort[size]);


	clock_t bubbleSortTime = clock();
        sort(arrayToSort, size);
        cout <<"Time taken by bubbleSort() in seconds: " <<(float)(clock()-bubbleSortTime)/CLOCKS_PER_SEC <<"\n"<< endl;


	clock_t qSortTime = clock();

	qsort(arrayToSort,size,sizeof(int),compare);

	cout <<"Time taken by quickSort() in seconds: " <<(float)(clock()-qSortTime )/CLOCKS_PER_SEC <<"\n"<< endl;

}
